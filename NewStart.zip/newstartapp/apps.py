from django.apps import AppConfig


class NewstartappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'newstartapp'
